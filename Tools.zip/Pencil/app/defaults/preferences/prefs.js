pref("toolkit.defaultChromeURI", "chrome://pencil/content/UI/Window.xul");

